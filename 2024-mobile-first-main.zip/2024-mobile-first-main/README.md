# 2024-mobile-first
 Exercicio de responsavidade em HTML e CSS
